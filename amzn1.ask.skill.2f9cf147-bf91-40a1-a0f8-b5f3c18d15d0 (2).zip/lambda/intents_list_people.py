from ask_sdk_core.dispatch_components import AbstractRequestHandler
from ask_sdk_core.handler_input import HandlerInput
from ask_sdk_core.utils import is_intent_name

from storage import get_all_people


# Patron Command: este handler actua como comando para listar personas registradas
class ListPeopleHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return is_intent_name("ListPeopleIntent")(handler_input)

    def handle(self, handler_input):
        people = get_all_people()

        if not people:
            speak = (
                "Aún no tienes personas registradas. "
                "Puedes decir: registra a una persona."
            )
            return handler_input.response_builder.speak(speak).ask(speak).response

        nombres = [p["name"] for p in people]
        lista_hablada = ", ".join(nombres)

        speak = (
            f"Tienes registradas a las siguientes personas: {lista_hablada}. "
            "¿Quieres ver los detalles de alguien?"
        )
        return handler_input.response_builder.speak(speak).ask("¿Deseas algo más?").response
