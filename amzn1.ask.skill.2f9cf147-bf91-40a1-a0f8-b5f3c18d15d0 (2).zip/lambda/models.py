import uuid
from datetime import datetime


def generate_id():
    return str(uuid.uuid4())[:8]


class Person:
    def __init__(
        self,
        person_id,
        name,
        birthdate,
        favorite_theme=None,
        favorite_colors=None,
        favorite_snacks=None,
        favorite_music=None,
        favorite_decor=None,
    ):
        self.person_id = person_id or generate_id()
        self.name = name
        self.birthdate = birthdate

        self.favorite_theme = favorite_theme or None
        self.favorite_colors = favorite_colors or []
        self.favorite_snacks = favorite_snacks or []
        self.favorite_music = favorite_music or None
        self.favorite_decor = favorite_decor or None

    def to_dict(self):
        return {
            "person_id": self.person_id,
            "name": self.name,
            "birthdate": self.birthdate,
            "favorite_theme": self.favorite_theme,
            "favorite_colors": self.favorite_colors,
            "favorite_snacks": self.favorite_snacks,
            "favorite_music": self.favorite_music,
            "favorite_decor": self.favorite_decor,
        }

    # Patron Factory Method: encapsulamos la creacion del objeto person a partir de un diccionario
    @staticmethod
    def from_dict(data):
        return Person(
            person_id=data.get("person_id"),
            name=data.get("name"),
            birthdate=data.get("birthdate"),
            favorite_theme=data.get("favorite_theme"),
            favorite_colors=data.get("favorite_colors"),
            favorite_snacks=data.get("favorite_snacks"),
            favorite_music=data.get("favorite_music"),
            favorite_decor=data.get("favorite_decor"),
        )


class Birthday:
    def __init__(self, person_id, date, guests):
        self.person_id = person_id
        self.date = date
        self.guests = guests

    def to_dict(self):
        return {
            "person_id": self.person_id,
            "date": self.date,
            "guests": self.guests,
        }

    # Patron Factory Method: encapsulamos la creacion del objeto birthday a partir de un diccionario
    @staticmethod
    def from_dict(data):
        return Birthday(
            person_id=data.get("person_id"),
            date=data.get("date"),
            guests=data.get("guests"),
        )
