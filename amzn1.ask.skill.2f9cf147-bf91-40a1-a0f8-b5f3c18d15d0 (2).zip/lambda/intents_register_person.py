from ask_sdk_core.dispatch_components import AbstractRequestHandler
from ask_sdk_core.utils import is_intent_name


# Patron Command: cada handler encapsula la logica de un intent especifico
class RegisterPersonIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return is_intent_name("RegisterPersonIntent")(handler_input)

    def handle(self, handler_input):
        session = handler_input.attributes_manager.session_attributes

        session["registrando_persona"] = True
        session["esperando"] = "name"
        session["data"] = {}

        speak = "Perfecto, vamos a registrar a alguien. ¿Cómo se llama?"
        return handler_input.response_builder.speak(speak).ask(speak).response
