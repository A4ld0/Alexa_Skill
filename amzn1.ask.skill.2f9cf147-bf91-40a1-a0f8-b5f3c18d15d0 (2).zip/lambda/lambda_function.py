import logging
import ask_sdk_core.utils as ask_utils

from ask_sdk_core.skill_builder import SkillBuilder
from ask_sdk_core.dispatch_components import (
    AbstractExceptionHandler,
    AbstractRequestHandler,
)
from ask_sdk_model import Response

from intents_register_person import RegisterPersonIntentHandler
from intents_continue_register import ContinuarRegistroPersonaHandler
from intents_confirm_register import ConfirmRegisterPersonHandler
from intents_list_people import ListPeopleHandler
from intents_show_person import ShowPersonHandler
from intents_generate_list import GenerateShoppingListHandler
from intents_update_shopping_list import MarkItemBoughtHandler, CloseShoppingListHandler

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


# Patron Command: cada handler de request actua como comando para un tipo de peticion
class LaunchRequestHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return ask_utils.is_request_type("LaunchRequest")(handler_input)

    def handle(self, handler_input):
        menu = main_menu_speech()
        speak = (
            "Bienvenido a Cumple Gestor. "
            "Puedo registrar personas, mostrar sus datos o generar una lista de compras. "
            + menu
        )
        return handler_input.response_builder.speak(speak).ask(menu).response


class HelpIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return ask_utils.is_intent_name("AMAZON.HelpIntent")(handler_input)

    def handle(self, handler_input):
        menu = main_menu_speech()
        speak = (
            "Puedo ayudarte registrando personas con sus gustos, "
            "mostrando la información guardada o generando una lista personalizada. "
            + menu
        )
        return handler_input.response_builder.speak(speak).ask(menu).response


class CancelOrStopIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return (
            ask_utils.is_intent_name("AMAZON.StopIntent")(handler_input)
            or ask_utils.is_intent_name("AMAZON.CancelIntent")(handler_input)
        )

    def handle(self, handler_input):
        speak = "Adiós, que tengas un excelente día."
        return handler_input.response_builder.speak(speak).response


class FallbackIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return ask_utils.is_intent_name("AMAZON.FallbackIntent")(handler_input)

    def handle(self, handler_input):
        session = handler_input.attributes_manager.session_attributes

        step = None
        if session.get("registrando_persona"):
            step = session.get("esperando")

        if step == "name":
            speak = (
                "No te entendí bien el nombre. "
                "Dime algo como: se llama Luis, o se llama Ana."
            )
        elif step == "birthdate":
            speak = (
                "No te entendí la fecha de nacimiento. "
                "Por ejemplo: nació el 5 de mayo de 2010."
            )
        elif step == "theme":
            speak = (
                "No te entendí la temática. "
                "Puedes decir: su temática favorita es dinosaurios, princesas, "
                "vaqueros o Mario Bros."
            )
        elif step == "colors":
            speak = (
                "No te entendí los colores. "
                "Di algo como: sus colores favoritos son rojo y azul, "
                "o solo es rojo."
            )
        elif step == "snacks":
            speak = (
                "No te entendí el snack favorito. "
                "Por ejemplo: le gusta la nieve, o le gustan las papitas y los "
                "chocolates."
            )
        elif step == "music":
            speak = (
                "No te entendí el tipo de música. "
                "Puedes decir: le gusta la banda, el rock o el reggaetón."
            )
        elif step == "decor":
            speak = (
                "No te entendí el estilo de decoración. "
                "Por ejemplo: decoración vaquera, gamer, minimalista "
                "o de colores pastel."
            )
        else:
            menu = main_menu_speech()
            speak = (
                "Lo siento, no entendí eso. "
                "Puedes decir: registra una persona, lista mis personas, "
                "o genera la lista de compras para Sofía."
                + menu
            )

        return handler_input.response_builder.speak(speak).ask(speak).response


class SessionEndedRequestHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return ask_utils.is_request_type("SessionEndedRequest")(handler_input)

    def handle(self, handler_input):
        return handler_input.response_builder.response


class CatchAllExceptionHandler(AbstractExceptionHandler):
    def can_handle(self, handler_input, exception):
        return True

    def handle(self, handler_input, exception):
        logger.error(exception, exc_info=True)
        speak = "Ocurrió un error inesperado. Intenta nuevamente."
        return handler_input.response_builder.speak(speak).ask(speak).response


def main_menu_speech():
    return (
        "¿Qué deseas hacer ahora? "
        "Puedes decir: registra una persona, "
        "lista las personas guardadas, "
        "o genera la lista de compras para alguien."
    )


# Patron Factory: centralizamos la creacion y configuracion del skill builder en una sola funcion
def create_skill_builder():
    sb = SkillBuilder()

    sb.add_request_handler(LaunchRequestHandler())
    sb.add_request_handler(ContinuarRegistroPersonaHandler())
    sb.add_request_handler(RegisterPersonIntentHandler())
    sb.add_request_handler(ConfirmRegisterPersonHandler())
    sb.add_request_handler(ListPeopleHandler())
    sb.add_request_handler(ShowPersonHandler())
    sb.add_request_handler(GenerateShoppingListHandler())
    sb.add_request_handler(HelpIntentHandler())
    sb.add_request_handler(CancelOrStopIntentHandler())
    sb.add_request_handler(FallbackIntentHandler())
    sb.add_request_handler(SessionEndedRequestHandler())
    sb.add_request_handler(MarkItemBoughtHandler())
    sb.add_request_handler(CloseShoppingListHandler())

    sb.add_exception_handler(CatchAllExceptionHandler())

    return sb


sb = create_skill_builder()
lambda_handler = sb.lambda_handler()
