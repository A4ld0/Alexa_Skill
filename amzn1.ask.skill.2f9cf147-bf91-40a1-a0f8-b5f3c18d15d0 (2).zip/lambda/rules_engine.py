# rules_engine.py

# Patron Strategy: separamos la logica de ajuste en un objeto intercambiable segun la persona
class AdjustmentStrategy:
    def apply(self, template_items, person_dict):
        raise NotImplementedError


class DefaultAdjustmentStrategy(AdjustmentStrategy):
    # Patron Strategy: implementamos una estrategia concreta de ajuste para listas de cumple
    def apply(self, template_items, person_dict):
        final = list(template_items)

        if person_dict.get("colors"):
            colores = ", ".join(person_dict["colors"])
            final.append(f"globos en colores {colores}")

        if person_dict.get("snacks"):
            snacks = ", ".join(person_dict["snacks"])
            final.append(f"botanas: {snacks}")

        if person_dict.get("music"):
            final.append(f"playlist de {person_dict['music']}")

        if person_dict.get("decor"):
            final.append(f"decoracion estilo {person_dict['decor']}")

        return final


# Patron Factory Method: centralizamos la seleccion de la estrategia segun los datos de la persona
def get_adjustment_strategy(person_dict):
    return DefaultAdjustmentStrategy()


def apply_adjustment_rules(template_items, person_dict):
    """
    Mantiene la firma original para no romper otros modulos
    Internamente delega en la estrategia seleccionada
    """
    strategy = get_adjustment_strategy(person_dict)
    return strategy.apply(template_items, person_dict)
