import json
import boto3
import os
from botocore.exceptions import ClientError

S3_BUCKET = os.environ.get("S3_PERSISTENCE_BUCKET")
S3_REGION = os.environ.get("S3_PERSISTENCE_REGION")
S3_KEY = "people.json"

s3 = boto3.client(
    "s3",
    region_name=S3_REGION,
    config=boto3.session.Config(signature_version='s3v4', s3={'addressing_style': 'path'})
)


# Patron Repository: encapsulamos el acceso a los datos de personas y listas para ocultar detalles de S3
# Patron Singleton: usamos una unica instancia del repositorio compartida por todo el modulo
class S3JsonRepository:
    def __init__(self, bucket, region, key, client):
        self.bucket = bucket
        self.region = region
        self.key = key
        self.client = client

    def load(self):
        try:
            response = self.client.get_object(Bucket=self.bucket, Key=self.key)
            raw = response["Body"].read().decode("utf-8")
            data = json.loads(raw)
        except ClientError as e:
            if e.response["Error"]["Code"] == "NoSuchKey":
                data = {"people": []}
            else:
                raise e

        if "people" not in data:
            data["people"] = []
        if "shopping_lists" not in data:
            data["shopping_lists"] = []

        return data

    def save(self, data):
        self.client.put_object(
            Bucket=self.bucket,
            Key=self.key,
            Body=json.dumps(data, ensure_ascii=False).encode("utf-8"),
            ContentType="application/json"
        )


_repository = S3JsonRepository(S3_BUCKET, S3_REGION, S3_KEY, s3)


def _load_s3_data():
    return _repository.load()


def _save_s3_data(data):
    _repository.save(data)


def _normalize(name: str) -> str:
    return name.strip().lower()


def save_person(person_dict):
    db = _load_s3_data()
    normalized = _normalize(person_dict["name"])

    db["people"] = [p for p in db["people"] if _normalize(p["name"]) != normalized]
    db["people"].append(person_dict)

    _save_s3_data(db)


def get_all_people():
    db = _load_s3_data()
    return db.get("people", [])


def get_person_by_name(name: str):
    normalized = _normalize(name)
    db = _load_s3_data()

    for p in db.get("people", []):
        if _normalize(p["name"]) == normalized:
            return p
    return None


def save_shopping_list(list_dict):
    """
    Guarda o actualiza una lista de compras en S3.
    Espera un dict con:
      - list_id
      - person_name
      - items: [{ "name": str, "bought": bool }]
      - closed: bool
    """
    db = _load_s3_data()
    lists_ = db.get("shopping_lists", [])

    lists_ = [l for l in lists_ if l.get("list_id") != list_dict["list_id"]]
    lists_.append(list_dict)

    db["shopping_lists"] = lists_
    _save_s3_data(db)


def get_open_list_for_person(name: str):
    """
    Obtiene la última lista ABIERTA para una persona (si existe).
    """
    normalized = _normalize(name)
    db = _load_s3_data()
    lists_ = db.get("shopping_lists", [])

    for l in reversed(lists_):
        if _normalize(l.get("person_name", "")) == normalized and not l.get("closed"):
            return l
    return None


def mark_item_as_bought(list_id: str, item_name: str):
    """
    Marca como comprado el primer ítem cuyo nombre contenga item_name (case-insensitive).
    Si todos quedan comprados, cierra la lista.
    Devuelve la lista actualizada o None si no encontró.
    """
    db = _load_s3_data()
    lists_ = db.get("shopping_lists", [])

    item_name_lower = item_name.lower()
    updated_list = None

    for l in lists_:
        if l.get("list_id") == list_id:
            for item in l.get("items", []):
                if item_name_lower in item.get("name", "").lower():
                    item["bought"] = True
                    break

            items = l.get("items", [])
            if items and all(i.get("bought") for i in items):
                l["closed"] = True

            updated_list = l
            break

    if updated_list:
        db["shopping_lists"] = lists_
        _save_s3_data(db)

    return updated_list


def close_shopping_list(list_id: str):
    """
    Cierra manualmente una lista (closed = True).
    """
    db = _load_s3_data()
    lists_ = db.get("shopping_lists", [])

    updated_list = None
    for l in lists_:
        if l.get("list_id") == list_id:
            l["closed"] = True
            updated_list = l
            break

    if updated_list:
        db["shopping_lists"] = lists_
        _save_s3_data(db)

    return updated_list
