from ask_sdk_core.dispatch_components import AbstractRequestHandler

from templates import normalize_theme, BASE_TEMPLATES
from rules_engine import apply_adjustment_rules


# Patron State: usamos un mapa de funciones por estado para organizar la conversacion y evitar muchos if
# Patron Command: el handler sigue siendo un comando para el flujo de registro
class ContinuarRegistroPersonaHandler(AbstractRequestHandler):
    """
    Maneja las respuestas intermedias del registro de persona,
    usando los flags de sesión:
      - registrando_persona: True/False
      - esperando: name | birthdate | theme | colors | snacks | music | decor | confirm
      - data: diccionario con los datos acumulados
    """

    def __init__(self):
        self.state_handlers = {
            "name": self._handle_name,
            "birthdate": self._handle_birthdate,
            "theme": self._handle_theme,
            "colors": self._handle_colors,
            "snacks": self._handle_snacks,
            "music": self._handle_music,
            "decor": self._handle_decor,
        }

    def can_handle(self, handler_input):
        session = handler_input.attributes_manager.session_attributes
        return (
            session.get("registrando_persona") is True
            and session.get("esperando") != "confirm"
        )

    def _get_user_text(self, handler_input):
        req = handler_input.request_envelope.request

        if hasattr(req, "intent") and req.intent and getattr(req.intent, "slots", None):
            for slot in req.intent.slots.values():
                if slot and slot.value:
                    return slot.value
        return None

    def handle(self, handler_input):
        session = handler_input.attributes_manager.session_attributes
        esperando = session.get("esperando")
        data = session.get("data", {})

        value = self._get_user_text(handler_input)

        if not value:
            if esperando == "birthdate":
                speak = (
                    "No te entendí la fecha de nacimiento. "
                    "Por ejemplo: nació el 5 de mayo de 2010."
                )
            elif esperando == "theme":
                speak = (
                    "No te entendí la temática. "
                    "Por ejemplo: su temática favorita es dinosaurios, princesas o fútbol."
                )
            elif esperando == "colors":
                speak = (
                    "No te entendí los colores. "
                    "Puedes decir: sus colores favoritos son rojo y azul, "
                    "o solo es rojo."
                )
            elif esperando == "snacks":
                speak = (
                    "No te entendí el snack favorito. "
                    "Por ejemplo: le gusta la nieve o le gustan las papitas."
                )
            elif esperando == "music":
                speak = (
                    "No te entendí el tipo de música. "
                    "Puedes decir: le gusta la banda, el rock o el pop."
                )
            elif esperando == "decor":
                speak = (
                    "No te entendí el estilo de decoración. "
                    "Por ejemplo: decoración vaquera, gamer o minimalista."
                )
            elif esperando == "confirm":
                speak = "Solo dime sí o no, ¿deseas guardar esta información?"
            else:
                speak = "No te entendí. ¿Puedes repetirlo?"

            return handler_input.response_builder.speak(speak).ask(speak).response

        handler = self.state_handlers.get(esperando)
        if handler:
            return handler(handler_input, value, session, data)

        speak = "¿Deseas guardar esta información?"
        session["esperando"] = "confirm"
        return handler_input.response_builder.speak(speak).ask(speak).response

    # A partir de aqui funciones de estado individuales

    def _handle_name(self, handler_input, value, session, data):
        data["name"] = value
        session["data"] = data
        session["esperando"] = "birthdate"

        speak = f"Perfecto. ¿Cuál es la fecha de nacimiento de {value}?"
        return handler_input.response_builder.speak(speak).ask(speak).response

    def _handle_birthdate(self, handler_input, value, session, data):
        req = handler_input.request_envelope.request
        slot = None
        if hasattr(req, "intent") and req.intent and getattr(req.intent, "slots", None):
            slot = req.intent.slots.get("birthdate")

        if slot and slot.value:
            data["birthdate"] = slot.value
        else:
            data["birthdate"] = value

        session["data"] = data
        session["esperando"] = "theme"

        speak = (
            "Muy bien. ¿Cuál es su temática favorita? "
            "Por ejemplo: dinosaurios, princesas, fútbol o videojuegos."
        )
        return handler_input.response_builder.speak(speak).ask(speak).response

    def _handle_theme(self, handler_input, value, session, data):
        theme_norm = normalize_theme(value)
        data["theme"] = theme_norm
        session["data"] = data

        template = BASE_TEMPLATES.get(theme_norm.lower())

        if template:
            preview_list = apply_adjustment_rules(template, data)
            preview_short = preview_list[:6]
            lista_hablada = ", ".join(preview_short)

            speak = (
                f"Genial, tema {theme_norm}. "
                f"Para ese tipo de fiesta podrías considerar comprar: {lista_hablada}. "
                "Más adelante ajustaré la lista con sus colores, snacks y música. "
                "Por ahora, ¿cuáles son sus colores favoritos?"
            )
        else:
            speak = (
                f"Perfecto, tema {theme_norm}. "
                "Más adelante puedo sugerirte una lista genérica de compras. "
                "Por ahora, ¿cuáles son sus colores favoritos?"
            )

        session["esperando"] = "colors"
        return handler_input.response_builder.speak(speak).ask(speak).response

    def _handle_colors(self, handler_input, value, session, data):
        colores = [c.strip() for c in value.split(",")]
        data["colors"] = colores
        session["data"] = data
        session["esperando"] = "snacks"

        speak = "Muy bien. ¿Cuál es su snack favorito?"
        return handler_input.response_builder.speak(speak).ask(speak).response

    def _handle_snacks(self, handler_input, value, session, data):
        snacks = [s.strip() for s in value.split(",")]
        data["snacks"] = snacks
        session["data"] = data
        session["esperando"] = "music"

        speak = "¿Qué tipo de música le gusta?"
        return handler_input.response_builder.speak(speak).ask(speak).response

    def _handle_music(self, handler_input, value, session, data):
        data["music"] = value
        session["data"] = data
        session["esperando"] = "decor"

        speak = "Perfecto. ¿Qué estilo de decoración te gustaría usar?"
        return handler_input.response_builder.speak(speak).ask(speak).response

    def _handle_decor(self, handler_input, value, session, data):
        data["decor"] = value
        session["data"] = data
        session["esperando"] = "confirm"

        speak = "¿Deseas guardar esta información?"
        return handler_input.response_builder.speak(speak).ask(speak).response
