from ask_sdk_core.dispatch_components import AbstractRequestHandler
from ask_sdk_core.utils import is_intent_name

from storage import (
    get_open_list_for_person,
    mark_item_as_bought,
    close_shopping_list,
)


# Patron Command: este handler marca articulos como comprados en la lista activa
class MarkItemBoughtHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return is_intent_name("MarkItemBoughtIntent")(handler_input)

    def handle(self, handler_input):
        session_attr = handler_input.attributes_manager.session_attributes
        intent = handler_input.request_envelope.request.intent
        slots = intent.slots or {}

        item_slot = slots.get("item_name")
        item_name = item_slot.value if item_slot else None

        if not item_name:
            speak = "¿Qué artículo quieres marcar como comprado?"
            return (
                handler_input.response_builder
                .speak(speak)
                .ask(speak)
                .response
            )

        person_name = session_attr.get("current_list_person")

        if not person_name:
            speak = (
                "No tengo ninguna lista de compras activa. "
                "Primero genera una lista diciendo, por ejemplo: "
                "genera la lista de compras para Sofía."
            )
            return handler_input.response_builder.speak(speak).response

        lista_abierta = get_open_list_for_person(person_name)
        if not lista_abierta:
            speak = f"No encontré ninguna lista de compras abierta para {person_name}."
            return handler_input.response_builder.speak(speak).response

        list_id = lista_abierta["list_id"]
        updated = mark_item_as_bought(list_id, item_name)

        if not updated:
            speak = (
                f"No encontré {item_name} en la lista de {person_name}. "
                "Intenta decir el nombre del artículo como lo mencioné al generar la lista."
            )
            return (
                handler_input.response_builder
                .speak(speak)
                .ask("¿Quieres intentar con otro artículo?")
                .response
            )

        session_attr["current_list_id"] = updated["list_id"]
        session_attr["current_list_person"] = updated["person_name"]

        restantes = [i["name"] for i in updated.get("items", []) if not i.get("bought")]

        if updated.get("closed"):
            speak = (
                f"Listo, marqué {item_name} como comprado. "
                f"Ya compraste todo para la fiesta de {person_name}. "
                "La lista ha quedado cerrada."
            )
            session_attr.pop("current_list_id", None)
            session_attr.pop("current_list_person", None)
            return handler_input.response_builder.speak(speak).response
        else:
            if restantes:
                faltan = ", ".join(restantes)
                speak = (
                    f"Listo, marqué {item_name} como comprado para {person_name}. "
                    f"Te falta comprar: {faltan}."
                )
            else:
                speak = (
                    f"Listo, marqué {item_name} como comprado para {person_name}. "
                    "Ya no veo más artículos pendientes."
                )
            return (
                handler_input.response_builder
                .speak(speak)
                .ask("¿Quieres marcar otro artículo como comprado?")
                .response
            )


# Patron Command: este handler cierra la lista de compras activa
class CloseShoppingListHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return is_intent_name("CloseShoppingListIntent")(handler_input)

    def handle(self, handler_input):
        session_attr = handler_input.attributes_manager.session_attributes
        intent = handler_input.request_envelope.request.intent
        slots = intent.slots or {}

        person_name = session_attr.get("current_list_person")

        if not person_name:
            speak = (
                "No tengo registrada ninguna lista activa. "
                "Primero genera una lista diciendo, por ejemplo: "
                "genera la lista de compras para Sofía."
            )
            return handler_input.response_builder.speak(speak).response

        lista_abierta = get_open_list_for_person(person_name)
        if not lista_abierta:
            speak = f"No encontré ninguna lista abierta para {person_name}."
            return handler_input.response_builder.speak(speak).response

        updated = close_shopping_list(lista_abierta["list_id"])

        if updated:
            session_attr.pop("current_list_id", None)
            session_attr.pop("current_list_person", None)

            speak = (
                f"Listo, la lista de compras para {person_name} ha sido cerrada. "
                "Si quieres, luego puedo generar una nueva lista."
            )
        else:
            speak = "Ocurrió un problema al intentar cerrar la lista."

        return handler_input.response_builder.speak(speak).response
