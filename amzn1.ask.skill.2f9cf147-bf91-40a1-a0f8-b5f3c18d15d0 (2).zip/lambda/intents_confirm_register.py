from ask_sdk_core.dispatch_components import AbstractRequestHandler
from ask_sdk_core.utils import is_intent_name

from storage import save_person


def _menu_speech():
    return (
        "¿Qué deseas hacer ahora? "
        "Puedes decir: registra otra persona, "
        "lista las personas guardadas, "
        "o genera la lista de compras para alguien."
    )


# Patron Command: este handler se encarga de confirmar o cancelar el registro de persona
class ConfirmRegisterPersonHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        session = handler_input.attributes_manager.session_attributes
        step = session.get("esperando")

        if step != "confirm":
            return False

        return (
            is_intent_name("AMAZON.YesIntent")(handler_input)
            or is_intent_name("AMAZON.NoIntent")(handler_input)
            or is_intent_name("ConfirmRegisterPersonIntent")(handler_input)
        )

    def handle(self, handler_input):
        session = handler_input.attributes_manager.session_attributes
        intent_name = handler_input.request_envelope.request.intent.name

        if intent_name in ("AMAZON.YesIntent", "ConfirmRegisterPersonIntent"):
            data = session.get("data", {})

            if data.get("name") and data.get("birthdate"):
                save_person(data)
                nombre = data.get("name", "la persona")
                speak = f"Perfecto, guardo la información de {nombre}. "
            else:
                speak = (
                    "No tenía datos completos para guardar, "
                    "así que no guardé nada. "
                )

            session["registrando_persona"] = False
            session["esperando"] = None
            session["data"] = {}

            menu = _menu_speech()
            speak += menu

            return (
                handler_input.response_builder
                .speak(speak)
                .ask(menu)
                .response
            )

        session["registrando_persona"] = False
        session["esperando"] = None
        session["data"] = {}

        menu = _menu_speech()
        speak = "De acuerdo, no guardaré los datos. " + menu

        return (
            handler_input.response_builder
            .speak(speak)
            .ask(menu)
            .response
        )
