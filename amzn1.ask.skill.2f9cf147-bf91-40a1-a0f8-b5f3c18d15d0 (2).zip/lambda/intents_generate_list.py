from ask_sdk_core.dispatch_components import AbstractRequestHandler
from ask_sdk_core.handler_input import HandlerInput
from ask_sdk_core.utils import is_intent_name

from storage import get_person_by_name, save_shopping_list
from templates import BASE_TEMPLATES
from rules_engine import apply_adjustment_rules
from models import generate_id


# Patron Command: este handler genera la lista de compras para una persona
class GenerateShoppingListHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return is_intent_name("GenerateShoppingListIntent")(handler_input)

    def handle(self, handler_input):
        intent = handler_input.request_envelope.request.intent
        slot = intent.slots.get("person_name")
        name = slot.value if slot else None

        if not name:
            speak = (
                "¿Para quién deseas generar la lista de compras? "
                "Por ejemplo: genera la lista de Sofía."
            )
            return handler_input.response_builder.speak(speak).ask(speak).response

        person = get_person_by_name(name)

        if not person:
            speak = (
                f"No encontré a {name} en tus registros. "
                "Puedes registrarlo diciendo: registra a {name}."
            )
            return handler_input.response_builder.speak(speak).ask("¿Quieres registrar a alguien?").response

        theme = person.get("theme")
        if not theme:
            speak = (
                f"{name} no tiene un tema registrado. "
                "Primero registra sus gustos completos."
            )
            return handler_input.response_builder.speak(speak).ask("¿Quieres registrar su información?").response

        existing_list = person.get("shopping_list")

        if existing_list:
            final_list = existing_list
        else:
            template = BASE_TEMPLATES.get(theme.lower())

            if not template:
                speak = (
                    f"No tengo una plantilla para el tema {theme}. "
                    "Puedo generar una lista genérica si quieres."
                )
                return handler_input.response_builder.speak(speak).ask("¿Deseas una lista genérica?").response

            final_list = apply_adjustment_rules(template, person)

        list_id = generate_id()
        shopping_list = {
            "list_id": list_id,
            "person_name": name,
            "items": [{"name": item, "bought": False} for item in final_list],
            "closed": False,
        }
        save_shopping_list(shopping_list)

        session_attr = handler_input.attributes_manager.session_attributes
        session_attr["current_list_id"] = list_id
        session_attr["current_list_person"] = name

        hablada = ", ".join(final_list)

        speak = (
            f"Esta es la lista sugerida para la fiesta de {name} con tema {theme}: "
            f"{hablada}. "
            "Cuando vayas comprando cosas, puedes decir por ejemplo: "
            "“marca globos verdes como comprado” o “cierra la lista de compras”. "
            "¿Quieres generar otra lista?"
        )

        return handler_input.response_builder.speak(speak).ask("¿Deseas algo más?").response
