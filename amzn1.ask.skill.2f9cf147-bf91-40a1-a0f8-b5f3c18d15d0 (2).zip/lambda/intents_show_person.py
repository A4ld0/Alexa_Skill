from ask_sdk_core.dispatch_components import AbstractRequestHandler
from ask_sdk_core.utils import is_intent_name

from storage import get_person_by_name


# Patron Command: este handler encapsula la consulta de informacion de una persona
class ShowPersonHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return is_intent_name("ShowPersonIntent")(handler_input)

    def handle(self, handler_input):
        req = handler_input.request_envelope.request
        intent = getattr(req, "intent", None)
        slots = getattr(intent, "slots", {}) if intent else {}

        slot = slots.get("person_name") if slots else None
        name = slot.value if (slot and slot.value) else None

        if not name:
            speak = (
                "¿De quién quieres ver la información? "
                "Puedes decir: muéstrame la información de Sofía."
            )
            return (
                handler_input.response_builder
                .speak(speak)
                .ask(speak)
                .response
            )

        name_clean = name.strip()

        person = get_person_by_name(name_clean)

        if not person:
            speak = (
                f"No encontré a {name_clean} en tus registros. "
                f"Puedes registrarlo diciendo: registra a {name_clean}."
            )
            return (
                handler_input.response_builder
                .speak(speak)
                .ask("¿Deseas registrar a alguien?")
                .response
            )

        detalles = []

        detalles.append(
            f"Su cumpleaños es el {person.get('birthdate', 'no registrado')}."
        )
        detalles.append(
            f"Su temática favorita es {person.get('theme', 'no registrada')}."
        )

        colors = person.get("colors")
        if colors:
            if isinstance(colors, (list, tuple)):
                colores_texto = ", ".join(colors)
            else:
                colores_texto = str(colors)
            detalles.append(f"Sus colores favoritos son {colores_texto}.")

        snacks = person.get("snacks")
        if snacks:
            if isinstance(snacks, (list, tuple)):
                snacks_texto = ", ".join(snacks)
            else:
                snacks_texto = str(snacks)
            detalles.append(f"Sus snacks favoritos son {snacks_texto}.")

        music = person.get("music")
        if music:
            detalles.append(f"Le gusta la música {music}.")

        decor = person.get("decor")
        if decor:
            detalles.append(f"Su decoración favorita es {decor}.")

        respuesta = " ".join(detalles)

        speak = (
            f"Esto es lo que tengo registrado de {person.get('name', name_clean)}: "
            f"{respuesta} ¿Quieres consultar otra persona?"
        )

        return (
            handler_input.response_builder
            .speak(speak)
            .ask("¿Deseas algo más?")
            .response
        )
