# Plantillas base por categoria
# Patron Template Object: centralizamos configuraciones estaticas por tema en un solo lugar
BASE_TEMPLATES = {
    "dinosaurios": [
        "globos verdes",
        "mantel de dinosaurios",
        "piñata temática",
        "servilletas verdes",
        "pastel de dinosaurio"
    ],
    "princesas": [
        "globos rosados",
        "coronas de princesa",
        "mantel rosa",
        "piñata de castillo",
        "pastel rosa"
    ],
    "carros": [
        "globos rojos",
        "banderines de carreras",
        "mantel de autos",
        "piñata de carro",
        "pastel de pista"
    ],
    "superheroes": [
        "globos azul y rojo",
        "mantel de acción",
        "máscaras de superhéroes",
        "piñata de superhéroe",
        "pastel temático"
    ],
    "videojuegos": [
        "globos neón",
        "mantel gamer",
        "stickers pixel",
        "piñata de joystick",
        "pastel gamer"
    ],
    "fantasia": [
        "globos pastel",
        "mantel púrpura",
        "decoración mágica",
        "piñata de estrella",
        "pastel mágico"
    ],
    "futbol": [
        "globos verdes y blancos",
        "mantel de cancha",
        "porterías pequeñas",
        "piñata de balón",
        "pastel de fútbol"
    ],
    "unicornios": [
        "globos pastel",
        "decoración de arcoíris",
        "piñata de unicornio",
        "mantel unicornio",
        "pastel de unicornio"
    ],
    "arcoiris": [
        "globos multicolor",
        "banderines arcoíris",
        "mantel multicolor",
        "piñata arcoíris",
        "pastel arcoíris"
    ]
}

# Normalizacion de temas
THEME_SYNONYMS = {
    "dino": "dinosaurios",
    "dinosaurio": "dinosaurios",
    "princesa": "princesas",
    "carro": "carros",
    "superheroe": "superheroes",
    "superhéroe": "superheroes",
    "videojuego": "videojuegos",
    "fantasía": "fantasia",
    "fútbol": "futbol",
    "unicornio": "unicornios",
    "arcoíris": "arcoiris",
}


def normalize_theme(spoken):
    text = spoken.lower().strip()
    return THEME_SYNONYMS.get(text, text)
